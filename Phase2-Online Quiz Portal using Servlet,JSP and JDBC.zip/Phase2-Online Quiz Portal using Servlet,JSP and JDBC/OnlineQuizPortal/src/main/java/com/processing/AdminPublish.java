package com.processing;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.Quiz;
import com.operations.AdminOperations;

/**
 * Servlet implementation class AdminPublish
 */
@WebServlet("/AdminPublish")
public class AdminPublish extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminPublish() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String title=request.getParameter("quiztitle");
		String categoryName=request.getParameter("categoryName");
		AdminOperations ao=new AdminOperations();
		PrintWriter out=response.getWriter();
		if(ao.publishQuiz(title)) {
			
			out.println("<html><body>");
			out.println("<h3>Quiz is published successfully<h3>");
			out.println("<a href='logOut.jsp'>Log Out</a>");
		}else {
			
			out.println("<html><body>");
			out.println("<h3 style='color:red'>Error Encountered<h3>");
			out.println("<a href='logOut.jsp'>Log Out</a>");
		}
		out.println("</body></html");
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
