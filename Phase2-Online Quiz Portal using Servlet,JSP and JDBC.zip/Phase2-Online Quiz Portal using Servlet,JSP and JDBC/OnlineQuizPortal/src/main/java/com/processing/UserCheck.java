package com.processing;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model.Quiz;
import com.model.UserDetails;
import com.operations.UserOperations;

/**
 * Servlet implementation class UserCheck
 */
@WebServlet("/UserCheck")
public class UserCheck extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserCheck() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UserDetails user=new UserDetails();
		UserOperations ops=new UserOperations();
		HttpSession session=request.getSession();
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		user=ops.ValidateUser(email,password);
		
		if(user!=null) {
			session.setAttribute("email",user.getEmail());
			session.setAttribute("password", user.getPassword());
			session.setAttribute("name", user.getName());
			RequestDispatcher rd=request.getRequestDispatcher("userDashBoard.jsp");
			rd.forward(request, response);
			
		}else {
			RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
			rd.include(request, response);
			PrintWriter out=response.getWriter();
			out.println("<h5 style='text-align:center;color:red'>Invalid Name/Password.Please Try Again</h5>");
		}
			
			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
