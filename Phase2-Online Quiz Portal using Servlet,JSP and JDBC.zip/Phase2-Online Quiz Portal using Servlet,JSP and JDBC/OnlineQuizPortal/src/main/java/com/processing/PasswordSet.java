package com.processing;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.Admin;

/**
 * Servlet implementation class PasswordSet
 */
@WebServlet("/PasswordSet")
public class PasswordSet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PasswordSet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String newPass=request.getParameter("newpass");
		String confirm=request.getParameter("conpass");
		if(newPass.equals(confirm)) {
			Admin ad=new Admin();
			ad.setAdminPassword(confirm);
			RequestDispatcher rd=request.getRequestDispatcher("adminDashBoard.jsp");
			rd.forward(request, response);
		}else {
			RequestDispatcher rd=request.getRequestDispatcher("changePassword.jsp");
			rd.include(request, response);
			PrintWriter out=response.getWriter();
			out.println("<h5 style='color:red'>Mismatch password.Please Try again</h5>");
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
