package com.processing;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.operations.AdminOperations;

/**
 * Servlet implementation class CheckCategory
 */
@WebServlet("/CheckCategory")
public class CheckCategory extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckCategory() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String name=request.getParameter("addCat");
		AdminOperations ao=new AdminOperations();
		if(ao.checkCategory(name)) {
			RequestDispatcher rd=request.getRequestDispatcher("addCategory.jsp");
			rd.include(request, response);
			PrintWriter out=response.getWriter();
			out.println("<h5 style='color:red'>The Category is already available</h5>");
		}else  {
			boolean b=ao.insertCategory(name);
			RequestDispatcher rd=request.getRequestDispatcher("adminDashBoard.jsp");
			rd.forward(request, response);
		}
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
