package com.model;

public class Quiz {
	private int qid;
	private String quiztitle;
	private int categoryId;
	
	public int getQid() {
		return qid;
	}
	public void setQid(int qid) {
		this.qid = qid;
	}
	public String getQuiztitle() {
		return quiztitle;
	}
	public void setQuiztitle(String quiztitle) {
		this.quiztitle = quiztitle;
	}
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
}
