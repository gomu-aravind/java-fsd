package com.operations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.connection.DBConnection;
import com.model.Question;
import com.model.Quiz;
import com.model.Score;
import com.model.UserDetails;

public class AdminOperations {
private Connection connect=null;
	
	public AdminOperations()  {
		try {
			connect=DBConnection.getConnection();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	//SHOW
	public List<Quiz> showQuiz() {
		List<Quiz> quiz=new ArrayList<Quiz>();
		try {
			String ins="select * from quiz";
			PreparedStatement ps=connect.prepareStatement(ins);
			 ResultSet rs=ps.executeQuery();
			 while(rs.next()) {
				 Quiz q=new Quiz();
				 q.setQid(rs.getInt("qid"));
				 q.setQuiztitle(rs.getString("quiztitle"));
				 q.setCategoryId(rs.getInt("CategoryId"));
				 quiz.add(q);
			 }
			 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return quiz;
	}
	
	public List<String> showAllCategoryName() {
		List<String> names=new ArrayList<String>();
		try {
			String ins="select categoryName from category";
			PreparedStatement ps=connect.prepareStatement(ins);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				names.add(rs.getString("categoryName"));
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return names;
	}
	
	
	public List<Question> showAllQuestions(String name){
		List<Question> qs=new ArrayList<Question>();
		try {
			String ins="select * from "+name;
			PreparedStatement ps=connect.prepareStatement(ins);
			ResultSet rs=ps.executeQuery();
			if(rs!=null) {
				while(rs.next()) {
					Question q=new Question();
					q.setSno(rs.getInt("sno"));
					q.setQuestion(rs.getString("question"));
					q.setOptionA(rs.getString("optionA"));
					q.setOptionB(rs.getString("optionB"));
					q.setOptionC(rs.getString("optionC"));
					q.setOptionD(rs.getString("optionD"));
					q.setAnswer(rs.getString("answer"));
					qs.add(q);
				}
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return qs;
	}
	
	
	public List<UserDetails> showAllUser(){
		List<UserDetails> users=new ArrayList<UserDetails>();
		try {
			String ins="select * from userinfo";
			PreparedStatement ps=connect.prepareStatement(ins);
			ResultSet rs=ps.executeQuery();
			if(rs!=null) {
				while(rs.next()) {
					UserDetails u=new UserDetails();
					u.setUserid(rs.getInt("userid"));
					u.setName(rs.getString("name"));
					u.setPhone(rs.getString("phone"));
					u.setEmail(rs.getString("email"));
					u.setPassword(rs.getString("password"));
					users.add(u);
				}
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return users;
	}
	
	public List<UserDetails> showAllUserId(){
		List<UserDetails> users=new ArrayList<UserDetails>();
		try {
			String ins="select userid from userinfo";
			PreparedStatement ps=connect.prepareStatement(ins);
			ResultSet rs=ps.executeQuery();
			if(rs!=null) {
				while(rs.next()) {
					UserDetails u=new UserDetails();
					u.setUserid(rs.getInt("userid"));
					users.add(u);
				}
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return users;
	}
	
	public List<Score> showAllUserMarks(String title) {
		List<Score> scores=new ArrayList<Score>();
		try {
			int qid=getQuizId(title);
			String ins="select * from score where qid=? order by  score desc , userid asc";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setInt(1,qid);
			 ResultSet rs=ps.executeQuery();
			 while(rs.next()) {
				 Score s=new Score();
				 s.setScoreid(rs.getInt("scoreid"));
				 s.setUserid(rs.getInt("userid"));
				 s.setQid(rs.getInt("qid"));
				 s.setScore(rs.getInt("score"));
				 scores.add(s);
			 }
			 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return scores;
	}
	public String getCategoryName(int no) {
		String s=null;
		try {
			String ins="select categoryName from category where categoryId=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setInt(1, no);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				s=rs.getString("categoryName");
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return s;
	}
	
	
	
	
	public int getCategoryId(String name) {
		int id=0;
		try {
			String ins="select categoryId from category where categoryName=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setString(1, name);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				id=rs.getInt("categoryId");
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return id;
	}
	
	public int getcategoryIdFromScore(int qid) {
		int id=0;
		try {
			String ins="select categoryId from quiz where qid=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setInt(1, qid);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				id=rs.getInt("categoryId");
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return id;
	}
	
	public int getQuizId(String title) {
		int id=0;
		try {
			String ins="select qid from quiz where quiztitle=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setString(1, title);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				id=rs.getInt("qid");
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return id;
	}
	
	public List<Question> getQuestionSet(String name,int no) {
		List<Question>ques=new ArrayList<Question>();
		try {
			String ins="select * from "+name+"  where sno=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setInt(1,no);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				Question q=new Question();
				q.setSno(rs.getInt("sno"));
				q.setQuestion(rs.getString("question"));
				q.setOptionA(rs.getString("optionA"));
				q.setOptionB(rs.getString("optionB"));
				q.setOptionC(rs.getString("optionC"));
				q.setOptionD(rs.getString("optionD"));
				q.setAnswer(rs.getString("answer"));
				ques.add(q);
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return ques;
	}
	
	public List<UserDetails> getUser(String s){
		List<UserDetails> user=new ArrayList<UserDetails>();
		try {
			int no=Integer.parseInt(s);
			String ins="select * from userinfo  where userid=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setInt(1,no);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				UserDetails u=new UserDetails();
				u.setUserid(rs.getInt("userid"));
				u.setName(rs.getString("name"));
				u.setPhone(rs.getString("phone"));
				u.setEmail(rs.getString("email"));
				u.setPassword(rs.getString("password"));
				user.add(u);
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return user;
		
	}
	
	public String getAllUser(int id){
		String name=null;
		try {
			String ins="select name from userinfo  where userid=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setInt(1,id);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				name=rs.getString("name");
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return name;
		
	}
	
	
	public String getQuizTitle(int qid) {
		String title=null;
		try {
			String ins="select quiztitle from quiz where qid=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setInt(1, qid);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				title=rs.getString("quiztitle");
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return title;
		
	}
	
	public boolean checkCategory(String name){
		boolean check=false;
		try {
			String ins="select * from category where categoryName=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setString(1,name);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				check=true;
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return check;
	}
	//------------------------------------------------------------
	
	//DELETE
	public boolean deleteQuizes(String title) {
		boolean delete=false;
		try {
			deleteQuizFromScore(title);
			deleteQuizFromPublish(title);
			String ins="delete from quiz where quiztitle=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setString(1, title);
			int r=ps.executeUpdate();
			if(r>=1) {
				delete=true;
			}
		
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return delete;
	}
	
	public boolean deleteQuizFromScore(String title) {
		boolean delete=false;
		try {
			int qid=getQuizId(title);
			String ins="delete from score where qid=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setInt(1, qid);
			int r=ps.executeUpdate();
			if(r>=1) {
				delete=true;
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return delete;
	}
	
	public boolean deleteQuizFromPublish(String title) {
		boolean delete=false;
		try {
			int qid=getQuizId(title);
			String ins="delete from publish where qid=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setInt(1, qid);
			int r=ps.executeUpdate();
			if(r>=1) {
				delete=true;
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return delete;
	}
	
	public boolean deleteQuestion(String name,int no) {
		boolean delete=false;
		try {
			
			String ins="delete from "+name+"  where sno=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setInt(1,no);
			int r=ps.executeUpdate();
			if(r>=1) {
				delete=true;
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return delete;
	}
	
	public boolean deleteUser(int no) {
		boolean delete=false;
		try {
			deleteUserScore(no);
			deleteUserFromPublish(no);
			String ins="delete from userinfo where userid=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setInt(1, no);
			int r=ps.executeUpdate();
			if(r>=1) {
				delete=true;
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return delete;
	}
	
	public boolean deleteUserScore(int no) {
		boolean delete=false;
		try {
			
			String ins="delete from score where userid=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setInt(1, no);
			int r=ps.executeUpdate();
			if(r>=1) {
				delete=true;
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return delete;
	}
	
	public boolean deleteUserFromPublish(int no) {
		boolean delete=false;
		try {
			
			String ins="delete from publish where userid=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setInt(1, no);
			int r=ps.executeUpdate();
			if(r>=1) {
				delete=true;
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return delete;
	}
	
	//INSERT
	public boolean addQuiz(String title,int no) {
		boolean check=false;
		try {			
			String ins="insert into quiz(quiztitle,categoryId) values(?,?)";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setString(1,title);
			ps.setInt(2, no);
			int rs=ps.executeUpdate();
			if(rs>=1)
				check=true;
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return check;
		
	}
	
	public boolean insertQuestion(Question q,String name) {
		boolean check=false;
		try {			
			String ins="insert into "+name+" (question,optionA,optionB,optionC,optionD,answer) values(?,?,?,?,?,?)";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setString(1, q.getQuestion());
			ps.setString(2, q.getOptionA());
			ps.setString(3, q.getOptionB());
			ps.setString(4, q.getOptionC());
			ps.setString(5, q.getOptionD());
			ps.setString(6, q.getAnswer());
			int rs=ps.executeUpdate();
			if(rs>=1)
				check=true;
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return check;
	}
	
	
	public boolean insertCategory(String name) {
		boolean check=false;
		try {			
			String ins="insert into category(categoryName) values (?)";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setString(1, name);
			int rs=ps.executeUpdate();
			if(rs>=1)
				check=true;
			createTableCat(name);
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return check;
	}
	
	public void createTableCat(String name) {
		try {			
			String ins="create table "+name+ "(sno int auto_increment primary key,"
					+ "question varchar (100),\r\n"
					+ "optionA varchar(20),\r\n"
					+ "optionB varchar(20),\r\n"
					+ "optionC varchar(20),\r\n"
					+ "optionD varchar(20),\r\n"
					+ "answer varchar(20)\r\n"
					+ ");";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.execute();
			
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	//UPDATE
	public boolean setQuizTable(Quiz quiz) {
		boolean check=false;
		try {
			String ins="update quiz set quiztitle=?,categoryId=? where qid=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setString(1, quiz.getQuiztitle());
			ps.setInt(2,quiz.getCategoryId());
			ps.setInt(3,quiz.getQid());
			 int r=ps.executeUpdate();
			 if(r>=1) {
				 check=true;
			 }
			 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return check;
	}
	
	public boolean setUser(UserDetails user) {
		boolean check=false;
		try {
			String ins="update userinfo set name=?,phone=?,email=?,password=? where userid=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setString(1,user.getName());
			ps.setString(2,user.getPhone());
			ps.setString(3,user.getEmail());
			ps.setString(4,user.getPassword());
			ps.setInt(5,user.getUserid());
			 int r=ps.executeUpdate();
			 if(r>=1) {
				 check=true;
			 }
			 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return check;
	}
	
	public boolean updateQuestionSet(Question q,String name) {
		boolean check=false;
		try {
			String ins="update "+name+" set question=?,optionA=?,optionB=?,optionC=?,optionD=?,answer=?where sno=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setString(1, q.getQuestion());
			ps.setString(2, q.getOptionA());
			ps.setString(3, q.getOptionB());
			ps.setString(4, q.getOptionC());
			ps.setString(5, q.getOptionD());
			ps.setString(6, q.getAnswer());
			ps.setInt(7, q.getSno());
			 int r=ps.executeUpdate();
			 if(r>=1) {
				 check=true;
			 }
			 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return check;
	}
	
	
	
	public boolean publishQuiz(String title) {
		boolean published=false;
		try {
			int id=getQuizId(title);
			List<UserDetails>users=showAllUserId();
			String ins="insert into publish(userid,qid) values (?,?)";
			PreparedStatement ps=connect.prepareStatement(ins);
			for(UserDetails u:users) {
				ps.setInt(1, u.getUserid());
				ps.setInt(2, id);
				int r=ps.executeUpdate();
				if(r>=1) {
					published=true;
				}else {
					published=false;
				}
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return published;
	}
	

}
