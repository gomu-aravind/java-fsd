package com.operations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.connection.DBConnection;
import com.model.Question;
import com.model.Quiz;
import com.model.Score;
import com.model.UserDetails;

public class UserOperations {
	private Connection connect=null;
	
	public UserOperations()  {
		try {
			connect=DBConnection.getConnection();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public boolean AddUser(UserDetails user) {
		boolean b=false;
		String inscmd="insert   into  userInfo (name,phone,email,password) values (?,?,?,?) ";
		try {
			PreparedStatement ps=connect.prepareStatement(inscmd);
			ps.setString(1, user.getName());
			ps.setString(2, user.getPhone());
			ps.setString(3, user.getEmail());
			ps.setString(4, user.getPassword());
			int rs=ps.executeUpdate();
			if(rs>=1)
				b=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return b;
	}
	//SELECT
	
	//Check User is present
	public UserDetails ValidateUser(String email,String password) {
		UserDetails user=null;
		try {
			String ins="select * from userInfo where email=? and password=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setString(1, email);
			ps.setString(2, password);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				user=new UserDetails();
				user.setName(rs.getString("name"));
				user.setPhone(rs.getString("phone"));
				user.setEmail(rs.getString("email"));
				user.setPassword(rs.getString("password"));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return user;
	}
	
	public boolean SearchUserCheck(UserDetails user) {
		boolean s=true;
		try {
			String name=user.getName();
			String ins="select * from userInfo where name=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setString(1, name);
			ResultSet rs=ps.executeQuery();
			
			
			if(rs.next()){
				if(rs.getString("name").equals(user.getName()) && rs.getString("phone").equals(user.getPhone()) && rs.getString("email").equals(user.getEmail()) && rs.getString("password").equals(user.getPassword())) {
				s=false;
			}
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return s;
	}
	
	public String getCategoryName(int no) {
		String s=null;
		try {
			String ins="select categoryName from category where categoryId=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setInt(1, no);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				s=rs.getString("categoryName");
			}
			
		}catch(SQLException e) {
			//e.printStackTrace();
		}
		return s;
	}
	
	public int getUserId(String name) {
		int id=0;
		try {
			String ins="select userid from userInfo where name=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setString(1, name);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				id=rs.getInt("userid");
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return id;
	}
	
	
	public String getUserName(int id) {
		String name=null;
		try {
			String ins="select name from userInfo where userid=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setInt(1, id);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				name=rs.getString("name");
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return name;
	}
	
	public List<Integer> getQuizIdPublish(int uid) {
		List<Integer> qid=new ArrayList<Integer>();
		try {
			String ins="select qid from publish where userid=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setInt(1, uid);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				qid.add(rs.getInt("qid"));
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return qid;
	}

	public List<Quiz> getQuizUser(int uid){
		List<Quiz> quizes=new ArrayList<Quiz>();
		try {
			List<Integer> qids=getQuizIdPublish(uid);
		String ins="select * from quiz where qid=?";
		PreparedStatement ps=connect.prepareStatement(ins);
		for(int i:qids) {
			ps.setInt(1, i);
		 ResultSet rs=ps.executeQuery();
		 while(rs.next()) {
			 Quiz q=new Quiz();
			 q.setQid(rs.getInt("qid"));
			 q.setQuiztitle(rs.getString("quiztitle"));
			 q.setCategoryId(rs.getInt("CategoryId"));
			 quizes.add(q);
		 }
		}
		 
	}catch(SQLException e) {
		e.printStackTrace();
	}
	return quizes;
	}
	
	public int getQuizId(String title) {
		int id=0;
		try {
			String ins="select qid from quiz where quiztitle=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setString(1, title);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				id=rs.getInt("qid");
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return id;
		
	}
	
	public String getQuizTitle(int qid) {
		String title=null;
		try {
			String ins="select quiztitle from quiz where qid=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setInt(1, qid);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				title=rs.getString("quiztitle");
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return title;
		
	}
	
	public int getCategoryId(int qid) {
		int id=0;
		try {
			String ins="select categoryId from quiz where qid=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setInt(1, qid);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				id=rs.getInt("categoryId");
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return id;
	}
	
	public List<Question> showQuestions(int catid){
		List<Question>quest=new ArrayList<Question>();
		try {
			String name=getCategoryName(catid);
			String ins="select * from "+name;
			PreparedStatement ps=connect.prepareStatement(ins);
			ResultSet rs=ps.executeQuery();
			if(rs!=null) {
				while(rs.next()) {
					Question q=new Question();
					q.setSno(rs.getInt("sno"));
					q.setQuestion(rs.getString("question"));
					q.setOptionA(rs.getString("optionA"));
					q.setOptionB(rs.getString("optionB"));
					q.setOptionC(rs.getString("optionC"));
					q.setOptionD(rs.getString("optionD"));
					q.setAnswer(rs.getString("answer"));
					quest.add(q);
					}
				}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return quest;
		
	}
	public boolean scoreUpdate(int userid,int score,String title) {
		int qid=getQuizId(title);
		boolean check=false;
		try {
			String inscmd="insert   into  score (userid,qid,score) values (?,?,?) ";
				PreparedStatement ps=connect.prepareStatement(inscmd);
				ps.setInt(1, userid);
				ps.setInt(2, qid);
				ps.setInt(3, score);
				int rs=ps.executeUpdate();
				if(rs>=1)
					check=true;
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
		return check;
	}
	
	
	public List<Quiz> showQuizLeaderBoard() {
		List<Quiz> quiz=new ArrayList<Quiz>();
		try {
			String ins="select * from quiz";
			PreparedStatement ps=connect.prepareStatement(ins);
			 ResultSet rs=ps.executeQuery();
			 while(rs.next()) {
				 Quiz q=new Quiz();
				 q.setQid(rs.getInt("qid"));
				 q.setQuiztitle(rs.getString("quiztitle"));
				 q.setCategoryId(rs.getInt("CategoryId"));
				 quiz.add(q);
			 }
			 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return quiz;
	}
	
	public List<Score> showLeaderBoard(String title) {
		List<Score> scores=new ArrayList<Score>();
		try {
			int qid=getQuizId(title);
			String ins="select * from score where qid=? order by  score desc , userid asc";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setInt(1,qid);
			 ResultSet rs=ps.executeQuery();
			 while(rs.next()) {
				 Score s=new Score();
				 s.setScoreid(rs.getInt("scoreid"));
				 s.setUserid(rs.getInt("userid"));
				 s.setQid(rs.getInt("qid"));
				 s.setScore(rs.getInt("score"));
				 scores.add(s);
			 }
			 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return scores;
	}

	public boolean setUserPassword(String pass,int userid) {
		boolean check=false;
		try {
			String ins="update userinfo set password=? where userid=?";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setString(1,pass);
			ps.setInt(2,userid);
			int rs=ps.executeUpdate();
			if(rs>=1)
				check=true;
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return check;
	}
	
	public List<Score> showIndividualScore(int userid){
		List<Score> scores=new ArrayList<Score>();
		try {
			String ins="select * from score where userid=? order by qid";
			PreparedStatement ps=connect.prepareStatement(ins);
			ps.setInt(1,userid);
			 ResultSet rs=ps.executeQuery();
			 while(rs.next()) {
				 Score s=new Score();
				 s.setScoreid(rs.getInt("scoreid"));
				 s.setUserid(rs.getInt("userid"));
				 s.setQid(rs.getInt("qid"));
				 s.setScore(rs.getInt("score"));
				 scores.add(s);
			 }
			 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return scores;
	}
	
}
