package com.automate;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.Duration;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class WebApp {

	public static WebDriver driver;
	
	@Parameters("browserName")
	@BeforeTest
	public void Setup(String browserName) 
	{
		if(browserName.equals("chrome"))
		{
			WebDriverManager.chromedriver().setup();
			driver =new ChromeDriver();
			System.out.println("--------Chrome Driver is Used--------");
		}
		
		if(browserName.equals("edge"))
		{
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
			System.out.println("--------Edge Driver is Used--------");
		}
		if(browserName.equals("firefox"))
		{
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			System.out.println("--------Firefox Driver is Used--------");
		}
		driver.get("https://www.flipkart.com/");
		driver.manage().window().maximize();
		driver.navigate().refresh();
	}
	
	@Test(priority = 1)
	public void closeLogin() throws InterruptedException, IOException {
	    System.out.println("Browser Result:");
	    System.out.println(driver.getTitle());

	    // Wait for a maximum of 10 seconds for the login pop-up element to be present or visible
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    // Check if the login pop-up element is present or visible
	    try {
	        // Using ExpectedConditions to wait for the element to be present or visible
	        WebElement loginPopup = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("body > div._2Sn47c > div > div > button")));

	        // If the login pop-up exists, click on it to close it
	        loginPopup.click();
	        Thread.sleep(2000);
	        System.out.println("1)Login pop-up is present and closed successfully.\n");
	        Reporter.log("Login pop-up is present and closed successfully.");
	    } catch (org.openqa.selenium.TimeoutException e) {
	        // If the login pop-up element is not found within the timeout, it means the login pop-up doesn't exist
	        System.out.println("1)Login pop-up is not present. Continuing with other progress.\n");
	        Reporter.log("Login pop-up is not present. Continuing with other progress.");
	    }
	}
	
	@Test(priority=2)
	public void PageLoadTime() throws Exception {
		long start_time = System.currentTimeMillis();
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeAsyncScript("window.setTimeout(arguments[arguments.length -1], 3000);");
		System.out.println("2)Passed Time: " +(System.currentTimeMillis() - start_time) + " milliSeconds");		
		Thread.sleep(2000);
	}
	
	@Test(priority=3)
	public void Search() throws Exception {
		driver.navigate().refresh();
		Thread.sleep(2000);
		driver.findElement(By.name("q")).sendKeys("iphone 13",Keys.ENTER);
		Thread.sleep(3500);
		System.out.println("3)The Title of the page is : "+driver.getTitle());
		Thread.sleep(2000);
	}
	
	@Test(priority=4)
	public void  ImageLoad() throws Exception {
		WebElement img=driver.findElement(By.xpath("//img[@class='_396cs4' and @alt='APPLE iPhone 13 (Starlight, 128 GB)']"));
		Thread.sleep(2000);
		Boolean p = (Boolean) ((JavascriptExecutor)driver) .executeScript("return arguments[0].complete " + "&& typeof arguments[0].naturalWidth != \"undefined\" " + "&& arguments[0].naturalWidth > 0", img);
	     //verify if status is true
	      if (p) {
	         System.out.println("4)Image on Screen is visible \n");
	      } else {
	         System.out.println("4)Image on Screen is not visible \n");
	      }
	      Thread.sleep(2000);
	}
	
	
	@Test(priority=5)
	public void scrollFeature() throws Exception {
		 long scrollHeight = (Long) ((JavascriptExecutor) driver).executeScript("return Math.max( document.body.scrollHeight, document.body.offsetHeight, document.documentElement.clientHeight, document.documentElement.scrollHeight, document.documentElement.offsetHeight );");
        // Get the viewport height
	     long viewportHeight = (Long) ((JavascriptExecutor) driver).executeScript("return window.innerHeight;");

	    // Compare the scroll height with the viewport height
	      boolean hasScroll = scrollHeight > viewportHeight;

	    // Output the result
	      if (hasScroll) {
	          System.out.println("5)The page has a scroll feature.");
	      }else {
	          System.out.println("5)The page does not have a scroll feature.");
	      }
	      Thread.sleep(2000);
	}
	
	@Test(priority=6)
	public void VerifyImageDownloadAndDisplay() throws Exception {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    // Simulate scrolling to the image position
	    Actions actions = new Actions(driver);
	    WebElement imageElement = driver.findElement(By.xpath("//img[@class='_396cs4' and @alt='APPLE iPhone 13 (Pink, 256 GB)']"));
	    actions.moveToElement(imageElement);
	    actions.perform();
	    Thread.sleep(3000);
	    
	    // Wait for the image to be visible on the page
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//img[@class='_396cs4' and @alt='APPLE iPhone 13 (Pink, 256 GB)']")));

	    // Get the image source URL
	    String imageUrl = imageElement.getAttribute("src");

	    // Verify image download
	    boolean isImageDownloaded = isUrlAccessible(imageUrl);
	    if (isImageDownloaded) {
	        System.out.println("6)Image downloaded and displayed in time!\n");
	    } else {
	        System.out.println("6)Image download failed or took too long!\n");
	    }
        scrollToTop(driver);
	    Thread.sleep(2000);
	}
	
	// Helper method to check if a URL is accessible (returns HTTP status 200) and to scroll to top
	private static void scrollToTop(WebDriver driver) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, 0);");
    }

	private boolean isUrlAccessible(String url) {
	    try {
	        HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
	        connection.setRequestMethod("HEAD");
	        int responseCode = connection.getResponseCode();
	        return responseCode == HttpURLConnection.HTTP_OK;
	    } catch (IOException e) {
	        return false;
	    }
	}
	
	@Test(priority=7)
	public void ScrollAndCheckContentRefresh() throws Exception {
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("scrollBy(0, 2000)");
		Thread.sleep(1500);
		js.executeScript("scrollBy(0, 2000)");
		Thread.sleep(2000);
		js.executeScript("scrollBy(0, 2000)");
		Thread.sleep(3000);
		js.executeScript("scrollBy(0, 2000)");
		Thread.sleep(3000);
		System.out.println("7)Reached to the bottom of the page");
		
		js.executeScript("scrollBy(0, -2000)");
		Thread.sleep(2000);
		js.executeScript("scrollBy(0, -2000)");
		Thread.sleep(2000);
		js.executeScript("scrollBy(0, -2000)");
		Thread.sleep(2000);
		js.executeScript("scrollBy(0, -2000)");
		Thread.sleep(2000);
		System.out.println("8)The page is scrolled to top of the page\n");
		Thread.sleep(2000);
	}
	
	
	@AfterTest
    public void tearDown() {
        if (driver != null) {
            driver.quit();
            System.out.println("****** End of the Test *********");
        }
    }
	
	
}
